JGrit
By David Foster, Sam Hartsfield, Derek Olejnik, and Taylor Perkins

To contact us, please visit our website at http://jgrit.googlecode.com,
where you can submit issues and make comments on pages (e.g. the FAQ Wiki Page).
You will need a Google account to leave feedback.

=== Introduction ===

JGrit is a tool for converting images from standard formats such as BMP, GIF,
and JPEG to source code that will display the image on the Game Boy Advance (GBA).

It is similar to the WinGrit tool found at http://www.coranac.com/projects/#grit
but can be used on the Windows, Linux, and Mac OS X platforms, whereas WinGrit
only works on Windows.

=== Installation ===

On Windows:
* Install Java 5 or later from http://java.sun.com/
* Double-click the "JGrit" program to run it.

On Linux:
* Install Sun Java 5 or later using either your favorite package manager
  or by downloading it from http://java.sun.com/
* Double-click the "JGrit.sh" program to run it.

On Mac OS X:
* Install to the Applications folder.
* Double-click the "JGrit" program to run it.

=== Usage ===

* When you run the program, click the Open toolbar button or menu item
  to select an image file that you want to convert to GBA source code.
  After selecting a file, click the GBA Export toolbar button or menu item.
* If you are performing a common conversion, such as converting an image
  to be used as a mode 3 bitmap image (such as a splash screen), select
  the conversion type from the list of tasks on the left of the window.
* If you are performing an advanced conversion which does not appear
  in the task list, click the Advanced... button to bring up the advanced
  export window.
* Select the conversion options you want to use.
* Click OK to export to image to source code.

== Properties File ==

* No matter the OS running under, on your first running of the program,
  a properties.xml file will be created in the parent folder of the
  software
* As of this moment, the properties file contains two customizable
  fields:
  - BinaryLocation: This is the path to the parent folder containing
    the first instance of the utilized binary folders.
    At this time, that would be the folder containing
    "grit/grit"
  - MainGUI: This can be set to one of two values (determining which
    format jgrit will open under):
      - GBAExportTaskStyle: Task view
      - GBAExportAdvanced: Advanced view
